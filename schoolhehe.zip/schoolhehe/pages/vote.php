<?php  
session_start();
include('../php/connect.php');
include "../php/functions.php";

	if(!isset($_SESSION['uid'])){
		exit( "<script>
                            setTimeout(function(){window.location.href='../pages/index.html';},1000);
              </script>");
	}else{
		$time = date('U')+50;
		$update = mysql_query("UPDATE `users` SET `online` = '".$time."' WHERE `id` = '".$_SESSION['uid']."'");

	}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="vote for school idol, school idol election">
    <meta name="author" content="Claire Liu">
    <link rel="icon" href="../image/favicon.ico">



    <title>SCHOOL IDOL Vote</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <!-- D3.js ...  -->
    <script src="../scatter/lib/d3.min.js"></script>

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../bootstrap/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="wakaka.css" rel="stylesheet">


<!-- 

<style>
* {box-sizing:border-box}
body {font-family: Verdana,sans-serif;margin:0}
.mySlides {display:none}

/* Slideshow container */
.slideshow-container {
  max-width: 1000px;
  position: relative;
  margin: auto;
}

/* Next & previous buttons */
.prev, .next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -22px;
  color: white;
  font-weight: bold;
  font-size: 18px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover, .next:hover {
  background-color: rgba(0,0,0,0.8);
}

/* Caption text */
.text {
  color: #f2f2f2;
  font-size: 15px;
  padding: 8px 12px;
  position: absolute;
  bottom: 8px;
  width: 100%;
  text-align: center;
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

/* The dots/bullets/indicators */
.dot {
  cursor:pointer;
  height: 13px;
  width: 13px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: background-color 0.6s ease;
}

.active, .dot:hover {
  background-color: #717171;
}

/* Fading animation */
.fade {
  -webkit-animation-name: fade;
  -webkit-animation-duration: 1.5s;
  animation-name: fade;
  animation-duration: 1.5s;
}

@-webkit-keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

@keyframes fade {
  from {opacity: .4} 
  to {opacity: 1}
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {
  .prev, .next,.text {font-size: 11px}
}
</style>

 -->


  </head>


<body>


<!-- ==================================== nav ==================================== -->


    <div class="site-wrapper">

      <div class="site-wrapper-inner">

        <div class="cover-container">

          <div class="masthead clearfix">
            <div class="inner">
              <h1 class="masthead-brand">SCHOOL IDOL</h1>

              <nav>
                <ul class="nav masthead-nav">


                <li><a href="#Home">Home</a></li>
                <li class="active"><a href="#">Vote</a></li>
                <li><a href="#moments">Moments</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">My <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="#">Profile</a></li>
                    <li><a href="#">Moments</a></li>
                    <li><a href="../php/logout.php">Log out</a></li>
                    <li role="separator" class="divider"></li>
                    <li class="dropdown-header">Account Settings</li>
                    <li><a href="#">Security</a></li>
                    <li><a href="#">Privacy</a></li>

                </ul>
              </nav>

            </div>
          </div>

       <div class="inner cover">
  <h1 class="cover-heading"> </h1>
  <p class="lead"> </p> 




<!-- ==================================== voting results ==================================== -->
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>


<div id="votePlot" style="height: 500px; min-width: 600px; max-width: 1000px; margin: 0 auto"></div>

<script type="text/javascript">

    Highcharts.chart('votePlot', {

    chart: {
        type: 'bubble',
        backgroundColor: null,
        plotBorderWidth: 0,
        zoomType: 'xy',
        borderColor: null
 
    },

    credits: {
      enabled: false
    },

    legend: {
        enabled: false
    },

    title:{
        text:''
    },
    subTitle:{
        text:''
    },

    xAxis: {
        gridLineWidth: 0,
        title: {
            text: 'x title'
        },
        labels: {
            format: '{value} unit'
        },


   // minorTickLength: 0,
   // tickLength: 0


        // plotLines: [{
        //     color: 'black',
        //     dashStyle: 'dot',
        //     width: 2,
        //     value: 65,
        //     label: {
        //         rotation: 0,
        //         y: 15,
        //         style: {
        //             fontStyle: 'italic'
        //         },
        //         text: 'this x'
        //     },
        //     zIndex: 3
        // }]
    },

    yAxis: {
        startOnTick: false,
        endOnTick: false,
        title: {
            text: 'Popularity'
        },
        labels: {
            format: '{value} '   // votes
        },
        maxPadding: 0.2,
        // plotLines: [{
        //     color: 'black',
        //     dashStyle: 'dot',
        //     width: 2,
        //     value: 50,
        //     label: {
        //         align: 'right',
        //         style: {
        //             fontStyle: 'italic'
        //         },
        //         text: 'this y',
        //         x: -10
        //     },
        //     zIndex: 3
        // }]
    },

    tooltip: {
        useHTML: true,
        headerFormat: '<table>',
        pointFormat: '<tr><th colspan="2"><h3>{point.idol}</h3></th></tr>' +
            '<tr><th>x values:</th><td>{point.x}unit</td></tr>' +
            '<tr><th>y values:</th><td>{point.y}unit</td></tr>' +
            '<tr><th>size of bubble:</th><td>{point.z}unit</td></tr>',
        footerFormat: '</table>',
        followPointer: true
    },

    plotOptions: {
        series: {
            dataLabels: {
                enabled: true,
                format: '{point.name}'
            }
        }
    },

    series: [{
        data: [
            { x: 95, y: 95, z: 13.8, name: '1', idol: 'amma' },    // name - school name, idol - idol name
            { x: 86.5, y: 102.9, z: 14.7, name: '2', idol: 'bmma' },
            { x: 80.8, y: 91.5, z: 15.8, name: 'c', idol: 'cmma' },
            { x: 80.4, y: 102.5, z: 12, name: 'd', idol: 'dmma' },
            { x: 80.3, y: 86.1, z: 11.8, name: 'e', idol: 'emma' },
            { x: 78.4, y: 70.1, z: 16.6, name: 'f', idol: 'f' },
            { x: 74.2, y: 68.5, z: 14.5, name: 'g', idol: 'g' },
            { x: 73.5, y: 83.1, z: 10, name: 'ha', idol: 'haha' },
            { x: 71, y: 93.2, z: 24.7, name: 'he', idol: 'hehe' },
            { x: 69.2, y: 57.6, z: 10.4, name: 'wa', idol: 'wa' },
            { x: 68.6, y: 20, z: 16, name: 'wh', idol: 'wahaha' },
            { x: 65.5, y: 126.4, z: 35.3, name: '3', idol: 'angelababy' },
            { x: 65.4, y: 50.8, z: 28.5, name: '4', idol: 'uqq' },
            { x: 63.4, y: 51.8, z: 15.4, name: '5', idol: 'unimelb' },
            { x: 64, y: 82.9, z: 31.3, name: '6', idol: 'xiaoming' }
        ]
    }]

});


</script>





   <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../jquery.min.js"><\/script>')</script>
    <script src="../bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../bootstrap/assets/js/ie10-viewport-bug-workaround.js"></script>



</body>
</html>
