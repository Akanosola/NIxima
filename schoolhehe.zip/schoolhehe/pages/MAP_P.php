<?php  
session_start();
include('../php/connect.php');
include "../php/functions.php";

	if(!isset($_SESSION['uid'])){
		exit( "<script>
                            setTimeout(function(){window.location.href='../pages/index.html';},1000);
              </script>");
	}else{
		$time = date('U')+50;
		$update = mysql_query("UPDATE `users` SET `online` = '".$time."' WHERE `id` = '".$_SESSION['uid']."'");

	}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    

    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="SCHOOL IDOL - HOME">
    <meta name="author" content="Claire Liu">
    <link rel="icon" href="../image/favicon.ico">



    <title>SCHOOL IDOL Homepage</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="../bootstrap/assets/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="wakaka.css" rel="stylesheet">


  </head>
  <body>

<!-- ==================================== nav ==================================== -->

<!-- 
    <div class="site-wrapper">

      <div class="site-wrapper-inner">

        <div class="cover-container">

          <div class="masthead clearfix">
            <div class="inner">
              <h1 class="masthead-brand">SCHOOL IDOL</h1>

              <nav>
                <ul class="nav masthead-nav">


                <li class="active"><a href="#">Home</a></li>
                <li><a href="#vote">Vote</a></li>
                <li><a href="#moments">Moments</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">My <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="#">Profile</a></li>
                    <li><a href="#">Moments</a></li>
                    <li><a href="#">Log out</a></li>
                    <li role="separator" class="divider"></li>
                    <li class="dropdown-header">Account Settings</li>
                    <li><a href="#">Security</a></li>
                    <li><a href="#">Privacy</a></li>

                </ul>
              </nav>

            </div>
          </div>

       <div class="inner cover">
  <h1 class="cover-heading"> </h1>
  <p class="lead"> </p> 

 -->



<!-- ==================================== nav option 2==================================== -->
    <div class="navbar-wrapper">
      <div class="container">

        <nav class="navbar navbar-inverse navbar-static-top">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="#">School Idol</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
              <ul class="nav navbar-nav">

                <li class="active"><a href="#">Home</a></li>
                <li><a href="#vote">Vote</a></li>
                <li><a href="#moments">Moments</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">My <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="#">Profile</a></li>
                    <li><a href="#">Moments</a></li>
                    <li><a href="../php/logout.php">Log out</a></li>
                    <li role="separator" class="divider"></li>
                    <li class="dropdown-header">Account Settings</li>
                    <li><a href="#">Security</a></li>
                    <li><a href="#">Privacy</a></li>


                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </nav>

      </div>
    </div>








<!-- ==================================== map ==================================== -->


<script src="http://d3js.org/d3.v3.min.js"></script>
<script src="../map/highmaps.js"></script> 
<script src="../map/au-all.js"></script> 
<script src="http://code.highcharts.com/maps/modules/data.js"></script>

<!-- <script src="https://code.highcharts.com/mapdata/countries/au/au-all.js"></script>
<script src="http://code.highcharts.com/maps/highmaps.js"></script>
<script src="http://code.highcharts.com/maps/modules/data.js"></script> -->


<div id="auMap"></div>

<script>


var data = [
 // use "id" in au-all.js
    ['au-nt', 0],    /*Northern Territory */
    ['au-wa', 1],   /* Western Australia*/
    //['au-ct', 2],    /*Australian Capital Territory*/
    ['au-sa', 3],     /*South Australia*/
    ['au-ql', 4],     /*Queensland*/
    // ['au-2557', 5],   /*Norfolk Island*/
    ['au-ts', 6],     /*Tasmania*/
    ['au-jb', 7],
    ['au-ns', 8],      /*New South Wales*/
    ['au-vi', 9]      /*Victoria*/
];




// Create the chart
Highcharts.mapChart('auMap', {
    chart: {
        map: 'countries/au/au-all',
        backgroundColor: null,

        style:{
            fontFamily:'helvetica',
            fontWeight:'normal',
            color: "contrast"
            
        }
    },
 
    credits: {
      enabled: false
    },

    title:{
        text:''
    },
    subTitle:{
        text:''
    },

    mapNavigation: {
        enabled: true,
        buttonOptions: {
            verticalAlign: 'bottom'
        }
    },

    colorAxis: {
        min: 1,
        minColor: '#efecf3',
        maxColor: '#990041'
    },


    legend: {
        enabled: false,
        title: {
            text: 'Active votes'
        }
    },


tooltip: {
  formatter: function() {
    return '1st: <b>'+ this.x + '<br/>' +
           '2nd: <b>'+ this.y +'<br/>'+
           '3rd: <b>'+ this.z
           ;
  }
},


    series: [{
        data: data,      // right now is rank 1-9 active level， the number can be total votes such that when tooltip is removed, total votes of this state will be displayed
        name: 'Active Level',
        states: {
            hover: {
                //fillOpacity:0.5;
                color:'orange' 
            }
        },
  
        dataLabels: {
            enabled: true,
            format: '{point.name}'
        }
    }]




});


</script>








<!-- ====================================direct to the voting area==================================== -->
          <div class="inner cover">

            <h1 class="cover-heading"> </h1> 
            <p class="lead"> </p>


            <p class="lead">
              <a href="#" class="btn btn-lg btn-default">Find your school idol</a>
            </p>
          </div>

        </div>

      </div>

    </div>

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../jquery.min.js"><\/script>')</script>
    <script src="../bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../bootstrap/assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>
