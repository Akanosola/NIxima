<?PHP 
session_start();
include('../php/connect.php');
include "../php/functions.php";
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">    

    <!-- ========================================================================== -->
    <meta name="description" content="school idol login, school idol home, find your school idol, school celebrity">
    <meta name="author" content="Claire Liu">
    <link rel="icon" href="image/favicon.ico">


    <title>Login - SCHOOL IDOL</title>

    <!-- Bootstrap core CSS -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <!-- CSS for this template -->
    <link href="css/Login.css" rel="stylesheet">

    <!-- jQuery -->
    <!-- <script src="../jquery.min.js"></script>  -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

  </head>
  <body>
<!-- ==================================== nav ==================================== -->


    <div class="site-wrapper">

      <div class="site-wrapper-inner">

        <div class="cover-container">

          <div class="masthead clearfix">
            <div class="inner">
              <h1 class="masthead-brand">SCHOOL IDOL</h1>

              <nav>
                <ul class="nav masthead-nav">


<li class="active"><a href="#Login"> Home </a></li>

                </ul>
              </nav>

            </div>
          </div>

       <div class="inner cover">
  <h1 class="cover-heading"> </h1>
  <p class="lead"> </p> 



<!-- ==================================== nav option 2==================================== -->

<!-- 
      <div class="navbar-wrapper">
      <div class="container">
        <nav class="navbar navbar-inverse navbar-static-top">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              <a class="navbar-brand" href="#">School Idol</a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
              <ul class="nav navbar-nav">

                <li class="active"><a href="#">Home </a></li>
                <li><a href="#vote">Vote</a></li>
                <li><a href="#moments">Moments</a></li>
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">My <span class="caret"></span></a>
                  <ul class="dropdown-menu">
                    <li><a href="#">Profile</a></li>
                    <li><a href="#">Moments</a></li>
                    <li><a href="#">Log out</a></li>
                    <li role="separator" class="divider"></li>
                    <li class="dropdown-header">Account Settings</li>
                    <li><a href="#">Security</a></li>
                    <li><a href="#">Privacy</a></li>


                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </nav>

      </div>
    </div>


 -->



 <!-- Intro Header -->
<section id="intro">
    <header class="intro">
        <div class="intro-body">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2">
                        <h1 class="brand-heading">FIND YOUR SCHOOL IDOL</h1>
                        <p class="intro-text">Become a school idol
                          <!--   <br>  -->    </p>
                        <a href="#Login" class="btn btn-circle page-scroll">
                            <i class="fa fa-angle-double-down animated"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
<section id="intro">






   <section id="Login">
<!-- ==================================== log / register ==================================== -->


<div class="container">

      <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-login">


          <div class="panel-heading">
            <div class="row">
              <div class="col-xs-6">
                

              </div>
              <div class="col-xs-6">
                

              </div>
            </div>
            <hr>
          </div>



          <div class="panel-body">
            <div class="row">
              <div class="col-lg-12">


<!-- ============login-form============ -->
          <!-- login directs to home map page -->
                <form id="login-form" action="cv_Home.html" method="post" role="form" style="display: block;">
                  
                  <div class="form-group">
                    <label>
					  
                 <?php
		if(!isset($_COOKIE['username'])) {

		
		echo "<center>Not have login yet!</center>";
		echo"	                    <script>
                            setTimeout(function(){window.location.href='../pages/index.html';},3000);
                    </script>";
	}else{
		mysql_query("UPDATE user SET `online` = '".date('U')."' WHERE `id` = '".$_COOKIE['username']."'");
 
		
		session_destroy();
		$_SESSION=array(); 
		echo "<center>log out</center>";
		}
 
	?>
                 
                 </label>
                  </div>

                  <div class="form-group text-center">
                    
                    
                  </div>
                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-6 col-sm-offset-3">
                       
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="row">
                      <div class="col-lg-12">

                      </div>
                    </div>
                  </div>
                </form>
 

<!-- ============register-form============ -->

                <form id="register-form" method="post" role="form" style="display: none;">
                  <div class="form-group">
                    <input type="text" name="username" id="username" tabindex="1" class="form-control" placeholder="Username" value="">
                  </div>
                  <div class="form-group">
                    <input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="Email Address" value="">
                  </div>
                  <div class="form-group">
                    <input type="password" name="password" id="password" tabindex="2" class="form-control" placeholder="Password">
                  </div>
                  <div class="form-group">
                    <input type="password" name="confirm-password" id="confirm-password" tabindex="2" class="form-control" placeholder="Confirm Password">
                  </div>



                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-6 col-sm-offset-3">
                        <input type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-register" value="Register Now">
                      </div>
                    </div>
                  </div>
                </form>


<!-- ======================== -->

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

 </section>

<!-- ============ log - reg      ============ -->
<script type="text/javascript">
  $(function() {

    $('#login-form-link').click(function(e) {
    $("#login-form").delay(100).fadeIn(100);
    $("#register-form").fadeOut(100);
    $('#register-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });

  $('#register-form-link').click(function(e) {
    $("#register-form").delay(100).fadeIn(100);
    $("#login-form").fadeOut(100);
    $('#login-form-link').removeClass('active');
    $(this).addClass('active');
    e.preventDefault();
  });

});

</script>

<br>
<br><br><br><br>
<br>



    <!-- =====================Footer===================== -->
    <section id="sillyFooter">
    <footer>
        <div class="container text-center">
            <p>Copyright &copy; Silly Kids 2017</p>
        </div>
    </footer>
    </section>




    <!-- ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->


    <!-- Bootstrap core JavaScript -->
    <!--     <script src="../bootstrap.min.js"></script>    -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../jquery.min.js"><\/script>')</script>

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="bootstrap/ie10-viewport-bug-workaround.css" rel="stylesheet">
  </body>
</html>
